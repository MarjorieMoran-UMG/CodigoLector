<?php
// Connect to the database
require 'connectDB.php';

// Incluye la biblioteca PhpSpreadsheet
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

if (isset($_POST["To_Excel"])) {
  
    // Set the default date to today if not provided
    $Log_date = empty($_POST['date_sel']) ? date("Y-m-d") : $_POST['date_sel'];
    
    $sql = "SELECT * FROM users_logs WHERE checkindate='$Log_date' ORDER BY id DESC";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        // Create a new Spreadsheet
        $spreadsheet = new Spreadsheet();
        
        // Add a worksheet
        $worksheet = $spreadsheet->getActiveSheet();

        // Set column headers
        $worksheet->fromArray(['ID', 'Name', 'Serial Number', 'Fingerprint ID', 'Date log', 'Time In', 'Time Out'], null, 'A1');

        // Add data
        $row = 2;
        while ($row_data = $result->fetch_assoc()) {
            $worksheet->fromArray([$row_data['id'], $row_data['username'], $row_data['serialnumber'], $row_data['fingerprint_id'], $row_data['checkindate'], $row_data['timein'], $row_data['timeout']], null, 'A'.$row);
            $row++;
        }

        // Set headers for Excel download
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="Usuarios_'.$Log_date.'.xlsx"');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Use php://output to send the file directly to the browser
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');

        exit();
    } else {
        header('Location: UsersLog.php');
        exit();
    }
}
?>
