<?php
/* Database connection settings */
	$servername = "localhost";
    $username = "u711338107_biometric";		//put your phpmyadmin username.(default is "root")
    $password = "Nueva.123#";			//if your phpmyadmin has a password put it here.(default is "root")
    $dbname = "u711338107_biometric";
    
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
?>