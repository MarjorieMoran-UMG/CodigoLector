<footer>
    <div class="footer">
        <p>&copy; 2023 biometricattendance. Todos los derechos reservados.</p>
    </div>
</footer>
