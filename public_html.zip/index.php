<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $servername = "localhost";
  $username = "u711338107_biometric";
  $password = "Nueva.123#";
  $dbname = "u711338107_biometric";

  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
  }

  $username = $_POST["username"];
  $password = $_POST["password"];

  $username = mysqli_real_escape_string($conn, $username);
  $password = mysqli_real_escape_string($conn, $password);

  $sql = "SELECT * FROM usuarios WHERE username='$username' AND password='$password'";
  $result = $conn->query($sql);

  if ($result->num_rows == 1) {
    $_SESSION["username"] = $username;
    header("Location: home.php");
    exit();
  } else {
    $error = "Usuario o contraseña incorrectos";
  }

  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="icon" type="image/jpg" href="/favicon.png"/>
  <title>Iniciar Sesión</title>
  
</head>

<body>
  <div class="login-container" style="height: 550px;">
  <h1 style="text-align: center; color: #21919c;">Bienvenido al Sistema de Control de Acceso</h1>
  <div class="container" style="align-items: center; text-align: center;">
      <img src="/favicon.png" class="" style="width: 80px; align-items: center; text-align: center;">
  </div>
  
    <h2>Iniciar Sesión</h2>
    <?php if (isset($error)) {
      echo "<p class='error-message'>$error</p>";
    } ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <label for="username">Usuario:</label>
      <input type="text" name="username" required>

      <label for="password">Contraseña:</label>
      <input type="password" name="password" required>

      <input type="submit" value="Iniciar Sesión">
    </form>
  </div>
</body>
</html>